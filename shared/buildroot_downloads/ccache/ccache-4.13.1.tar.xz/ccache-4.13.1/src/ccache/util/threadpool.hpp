// Copyright (C) 2019-2025 Joel Rosdahl and other contributors
//
// See doc/authors.adoc for a complete list of contributors.
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation; either version 3 of the License, or (at your option)
// any later version.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along with
// this program; if not, write to the Free Software Foundation, Inc., 51
// Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

#pragma once

#include <ccache/util/noncopyable.hpp>

#include <condition_variable>
#include <cstddef>
#include <functional>
#include <future>
#include <limits>
#include <memory>
#include <mutex>
#include <queue>
#include <thread>
#include <type_traits>
#include <utility>
#include <vector>

namespace util {

class ThreadPool : util::NonCopyable
{
public:
  explicit ThreadPool(
    size_t number_of_threads,
    size_t task_queue_max_size = std::numeric_limits<size_t>::max());
  ~ThreadPool() noexcept;

  void enqueue_detach(std::function<void()> function);

  // Enqueue a task that returns a value. Returns a std::future that can be
  // used to retrieve the result once the task completes.
  template<typename F, typename... Args>
  auto enqueue(F&& f, Args&&... args)
    -> std::future<typename std::invoke_result<F, Args...>::type>;

  void shut_down() noexcept;

private:
  std::vector<std::thread> m_worker_threads;
  std::queue<std::function<void()>> m_task_queue;
  size_t m_task_queue_max_size;
  bool m_shutting_down = false;
  std::mutex m_mutex;
  std::condition_variable m_worker_cv;
  std::condition_variable m_producer_cv;

  void worker_thread_main();
};

template<typename F, typename... Args>
auto
ThreadPool::enqueue(F&& f, Args&&... args)
  -> std::future<typename std::invoke_result<F, Args...>::type>
{
  using return_type = typename std::invoke_result<F, Args...>::type;

  auto task = std::make_shared<std::packaged_task<return_type()>>(
    std::bind(std::forward<F>(f), std::forward<Args>(args)...));

  std::future<return_type> result = task->get_future();

  enqueue_detach([task]() { (*task)(); });

  return result;
}

} // namespace util
